// export default (router) => {
// 	router.get('/', (req, res) => res.send('Hello, World!'));
// };
export default {
    id: 'weather',
    handler: (router) => {
        router.get('/', async (req, res) => {
            try {
                const response = await fetch(`https://api.open-meteo.com/v1/forecast?current_weather=true&${req._parsedUrl.query}`);
                console.log(response, "jjj");
                if (response.ok) {
                    res.json(await response.json());
                } 
				else { 
                    res.status(response.status).send(response.statusText);
                }
            } catch(error) {
                res.status(500).send({error: `${error.message}`});
            }
        })
    }
}
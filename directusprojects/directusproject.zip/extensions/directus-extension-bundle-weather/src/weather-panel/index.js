import PanelComponent from './panel.vue';

export default {
	id: 'weather-panel',
	name: 'Weather',
	icon: 'box',
	description: 'This is my custom panel!',
	component: PanelComponent,
	options: [
		// {
		// 	field: 'text',
		// 	name: 'Text',
		// 	type: 'string',
		// 	meta: {
		// 		interface: 'input',
		// 		width: 'full',
		// 	},
		// },
		{
			field: 'longitude',
			name: 'Longitude',
			type: 'string',
			meta: {
				interface: 'input',
				width: 'half',
			},
		},
		{
			field: 'latitude',
			name: 'Latitude',
			type: 'string',
			meta: {
				interface: 'input',
				width: 'half',
			},
		},
	],
	minWidth: 12,
	minHeight: 8,
};

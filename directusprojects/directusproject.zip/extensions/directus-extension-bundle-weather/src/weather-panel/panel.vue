<template>
	<div class="text" :class="{ 'has-header': showHeader }">
		{{ weather }}
	</div>
</template>

<script>
import { useApi } from '@directus/extensions-sdk'; 
import { ref } from 'vue'; 
export default {
	props: {
		showHeader: {
			type: Boolean,
			default: false,
		},
		longitude: { 
			type: String,  
			default: '0',  
		},  
		latitude: {  
			type: String,  
			default: '0',  
		},  
	},
	setup(props) {
		const api = useApi();
		const weather = ref({});
		
		async function fetchData() {
			const response = await api.get(`/weather?longitude=${props.longitude}&latitude=${props.latitude}`);
			weather.value = response.data;
		};
		fetchData();

		return { weather };
	},
};

</script>

<style scoped>
.text {
	padding: 12px;
}

.text.has-header {
	padding: 0 12px;
}
</style>

<template>
	<v-list nav v-if="pages">
		<v-list-item v-for="navItem in pages" :key="navItem.to" :active="navItem.uri == current" :to="navItem.to">
			<v-list-item-icon><v-icon :name="navItem.icon" :color="navItem.color" /></v-list-item-icon>
			<v-list-item-content>
				<v-text-overflow :text="navItem.label" />
			</v-list-item-content>
		</v-list-item>
	</v-list>
</template>


<script>
export default{
	name: 'PageNavigation',
	inheritAttrs: false,
	props: {
		current: {
			type: String,
			default: null,
		},
		pages: {
			type: Array,
			default: [],
		}
	},
};
</script>

<!-- <div class="lp-container">
	<div class="lp-banner" v-if="page_banner">
		<img :src="page_banner" alt=""/>
	</div>
	<div class="lp-cards" v-if="page_cards">
		<div class="lp-card" v-for="card in page_cards.filter(item => (item.uri != page))" :key="card.uri" @click="change_page(card.to)">
			<img class="lp-card-image" :src="card.image" alt=""/>
			<span class="lp-card-title">{{ card.label }}</span>
		</div>
	</div>
	<div class="lp-body" v-if="page_body" v-html="page_body"></div>
</div> -->
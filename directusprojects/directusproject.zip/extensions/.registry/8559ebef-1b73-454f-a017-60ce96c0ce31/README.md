# Solarized Theme

Your favorite kind of yellow theme. Now in Directus.

![](https://raw.githubusercontent.com/directus-labs/extension-solarized-theme/main/docs/screenshot.png)
